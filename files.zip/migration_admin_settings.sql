-- ============================================================
-- BdStockOMS — Admin Settings DB Migration
-- Run this in SQL Server against your BdStockOMS database
-- ============================================================

-- ── AppSettings key-value store ────────────────────────────────
CREATE TABLE IF NOT EXISTS AppSettings (
    [Key]       NVARCHAR(200) NOT NULL PRIMARY KEY,
    [Value]     NVARCHAR(MAX) NOT NULL DEFAULT '',
    [Category]  NVARCHAR(50)  NOT NULL DEFAULT 'general',
    [UpdatedAt] DATETIME2     NOT NULL DEFAULT GETUTCDATE(),
    [UpdatedBy] NVARCHAR(100) NOT NULL DEFAULT 'system'
);

-- ── AuditLog table ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS AuditLogs (
    [Id]         NVARCHAR(36)  NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [UserName]   NVARCHAR(100) NOT NULL,
    [Action]     NVARCHAR(100) NOT NULL,
    [Resource]   NVARCHAR(100) NOT NULL,
    [ResourceId] NVARCHAR(200) NULL,
    [OldValue]   NVARCHAR(MAX) NULL,
    [NewValue]   NVARCHAR(MAX) NULL,
    [IpAddress]  NVARCHAR(50)  NOT NULL DEFAULT '',
    [UserAgent]  NVARCHAR(500) NULL,
    [Severity]   NVARCHAR(20)  NOT NULL DEFAULT 'info',
    [Timestamp]  DATETIME2     NOT NULL DEFAULT GETUTCDATE()
);
CREATE INDEX IX_AuditLogs_Timestamp ON AuditLogs ([Timestamp] DESC);
CREATE INDEX IX_AuditLogs_UserName  ON AuditLogs ([UserName]);
CREATE INDEX IX_AuditLogs_Resource  ON AuditLogs ([Resource]);

-- ── FeeStructures table ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS FeeStructures (
    [Id]                NVARCHAR(36)    NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [Name]              NVARCHAR(100)   NOT NULL,
    [BrokeragePercent]  DECIMAL(10,4)   NOT NULL DEFAULT 0.40,
    [SecdFeePercent]    DECIMAL(10,4)   NOT NULL DEFAULT 0.015,
    [CdblFeePercent]    DECIMAL(10,4)   NOT NULL DEFAULT 0.015,
    [VatPercent]        DECIMAL(10,4)   NOT NULL DEFAULT 15.0,
    [AitPercent]        DECIMAL(10,4)   NOT NULL DEFAULT 0.05,
    [MinBrokerage]      DECIMAL(18,2)   NOT NULL DEFAULT 10.0,
    [ApplyToCategory]   NVARCHAR(10)    NOT NULL DEFAULT 'ALL',
    [IsActive]          BIT             NOT NULL DEFAULT 1,
    [EffectiveFrom]     DATE            NULL,
    [CreatedAt]         DATETIME2       NOT NULL DEFAULT GETUTCDATE(),
    [UpdatedAt]         DATETIME2       NOT NULL DEFAULT GETUTCDATE()
);

-- ── Roles table ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS SystemRoles (
    [Id]          NVARCHAR(36)   NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [Name]        NVARCHAR(100)  NOT NULL UNIQUE,
    [Description] NVARCHAR(500)  NULL,
    [IsSystem]    BIT            NOT NULL DEFAULT 0,
    [Permissions] NVARCHAR(MAX)  NOT NULL DEFAULT '[]',  -- JSON array
    [CreatedAt]   DATETIME2      NOT NULL DEFAULT GETUTCDATE()
);

-- ── API Keys table ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ApiKeys (
    [Id]          NVARCHAR(36)   NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [Name]        NVARCHAR(100)  NOT NULL,
    [KeyHash]     NVARCHAR(256)  NOT NULL,  -- SHA-256 of the actual key
    [KeyPrefix]   NVARCHAR(20)   NOT NULL,  -- First 8 chars for display
    [Scopes]      NVARCHAR(500)  NOT NULL DEFAULT '',
    [ExpiresAt]   DATE           NULL,
    [LastUsedAt]  DATETIME2      NULL,
    [IsActive]    BIT            NOT NULL DEFAULT 1,
    [CreatedAt]   DATETIME2      NOT NULL DEFAULT GETUTCDATE(),
    [CreatedBy]   NVARCHAR(100)  NOT NULL DEFAULT 'system'
);

-- ── Announcements table ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS Announcements (
    [Id]        NVARCHAR(36)  NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [Title]     NVARCHAR(200) NOT NULL,
    [Body]      NVARCHAR(MAX) NOT NULL,
    [Type]      NVARCHAR(20)  NOT NULL DEFAULT 'info',
    [Active]    BIT           NOT NULL DEFAULT 1,
    [Pinned]    BIT           NOT NULL DEFAULT 0,
    [ExpiresAt] DATE          NULL,
    [CreatedAt] DATETIME2     NOT NULL DEFAULT GETUTCDATE(),
    [UpdatedAt] DATETIME2     NOT NULL DEFAULT GETUTCDATE()
);

-- ── Backup History table ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS BackupHistory (
    [Id]          NVARCHAR(36)  NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [Size]        NVARCHAR(20)  NULL,
    [Duration]    NVARCHAR(20)  NULL,
    [Status]      NVARCHAR(20)  NOT NULL DEFAULT 'running',
    [FilePath]    NVARCHAR(500) NULL,
    [S3Key]       NVARCHAR(500) NULL,
    [ErrorDetail] NVARCHAR(MAX) NULL,
    [CreatedAt]   DATETIME2     NOT NULL DEFAULT GETUTCDATE(),
    [CompletedAt] DATETIME2     NULL
);

-- ── IP Whitelist table ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS IpWhitelist (
    [Id]       NVARCHAR(36)  NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [Ip]       NVARCHAR(50)  NOT NULL,
    [Label]    NVARCHAR(100) NULL,
    [AddedAt]  DATE          NOT NULL DEFAULT CAST(GETUTCDATE() AS DATE),
    [AddedBy]  NVARCHAR(100) NOT NULL DEFAULT 'admin'
);

-- ── Seed default roles ─────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM SystemRoles WHERE Name = 'SuperAdmin')
INSERT INTO SystemRoles ([Name], [Description], [IsSystem], [Permissions]) VALUES
    ('SuperAdmin',     'Full system access',                1, '[]'),
    ('BranchManager',  'Branch-level operations',           0, '[]'),
    ('Dealer',         'Order entry and portfolio view',    0, '[]'),
    ('Viewer',         'Read-only access',                  0, '[]');

-- ── Seed default fee structure ─────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM FeeStructures)
INSERT INTO FeeStructures ([Name],[BrokeragePercent],[SecdFeePercent],[CdblFeePercent],[VatPercent],[AitPercent],[MinBrokerage],[ApplyToCategory])
VALUES
    ('Standard (A/B Category)', 0.40, 0.015, 0.015, 15.0, 0.05, 10.0, 'ALL'),
    ('Z Category',              0.50, 0.015, 0.015, 15.0, 0.05, 15.0, 'Z');

-- ── Seed default settings ──────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM AppSettings WHERE [Key] = 'general.systemName')
INSERT INTO AppSettings ([Key],[Value],[Category]) VALUES
    ('general.systemName',            'BdStockOMS',           'general'),
    ('general.systemCode',            'BDSTK',                'general'),
    ('general.timezone',              'Asia/Dhaka',           'general'),
    ('general.currency',              'BDT',                  'general'),
    ('general.dateFormat',            'DD/MM/YYYY',           'general'),
    ('general.sessionTimeoutMinutes', '30',                   'general'),
    ('general.maxLoginAttempts',      '5',                    'general'),
    ('general.maintenanceMode',       'false',                'general'),
    ('market.dseOpenTime',            '10:00',                'market'),
    ('market.dseCloseTime',           '14:30',                'market'),
    ('market.circuitBreakerUpPercent','10',                   'market'),
    ('market.circuitBreakerDownPercent','10',                 'market'),
    ('market.settlementDays',         '2',                    'market'),
    ('trading.maxOrderValue',         '10000000',             'trading'),
    ('trading.rmsCheckEnabled',       'true',                 'trading'),
    ('trading.allowMarginTrading',    'true',                 'trading'),
    ('trading.requireBOForOrder',     'true',                 'trading'),
    ('notif.emailEnabled',            'true',                 'notifications'),
    ('notif.notifyOnOrderFill',       'true',                 'notifications'),
    ('retention.orderHistoryDays',    '365',                  'retention'),
    ('retention.auditLogDays',        '730',                  'retention');
