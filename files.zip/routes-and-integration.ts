// ============================================================
// BdStockOMS — Router additions for Admin Settings
// File: BdStockOMS.Client/src/App.tsx  (routes section)
//
// Add these routes inside your <Routes> block.
// AdminSettingsPage handles all /settings/* sub-sections
// via its own internal sidebar — no separate page per section.
// ============================================================

// ── 1. Import ─────────────────────────────────────────────────
import AdminSettingsPage from './pages/AdminSettingsPage';

// ── 2. Route Definitions (add inside <Routes>) ────────────────
/*
  <Route path="/settings/*" element={<AdminSettingsPage />} />
*/

// ── 3. AdminSettingsPage URL-sync version ─────────────────────
// If you want the URL to reflect the active settings section
// (e.g. /settings/market, /settings/audit-log), update
// AdminSettingsPage.tsx to use useParams/useNavigate like this:

import { useParams, useNavigate } from 'react-router-dom';

// Replace the useState for activeSection with:
//
//   const { section = 'general' } = useParams<{ section: string }>();
//   const navigate = useNavigate();
//
//   // When switching sections:
//   navigate(`/settings/${sectionId}`);
//
// And update the Route to:
//   <Route path="/settings/:section" element={<AdminSettingsPage />} />
//   <Route path="/settings" element={<Navigate to="/settings/general" replace />} />

// ── 4. Placeholder admin pages (for /admin/* routes) ──────────
// File: BdStockOMS.Client/src/pages/admin/PlaceholderPage.tsx

export function AdminPlaceholderPage({ title }: { title: string }) {
  return (
    <div className="flex h-full items-center justify-center">
      <div className="text-center">
        <div className="mb-3 text-4xl">🚧</div>
        <h2 className="text-lg font-semibold text-[var(--t-text1)]">{title}</h2>
        <p className="mt-1 text-sm text-[var(--t-text3)]">This page is under construction — Day 66</p>
      </div>
    </div>
  );
}

// ── 5. Full App.tsx routes example ────────────────────────────
/*
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import DashboardPage from './pages/DashboardPage';
import AdminSettingsPage from './pages/AdminSettingsPage';
import { AdminPlaceholderPage } from './pages/admin/PlaceholderPage';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route index element={<DashboardPage />} />
          <Route path="trading" element={<TradingPage />} />
          <Route path="portfolio" element={<PortfolioPage />} />
          <Route path="market" element={<MarketPage />} />

          // Admin sub-pages
          <Route path="admin/brokers"    element={<AdminPlaceholderPage title="Broker Management" />} />
          <Route path="admin/branches"   element={<AdminPlaceholderPage title="Branch Management" />} />
          <Route path="admin/bo-accounts"element={<AdminPlaceholderPage title="BO Account Management" />} />
          <Route path="admin/users"      element={<AdminPlaceholderPage title="User Management" />} />
          <Route path="admin/fix"        element={<AdminPlaceholderPage title="FIX Gateway" />} />
          <Route path="admin/activities" element={<AdminPlaceholderPage title="Activity Log" />} />

          // Settings — handled by AdminSettingsPage internal sidebar
          <Route path="settings" element={<Navigate to="/settings/general" replace />} />
          <Route path="settings/:section" element={<AdminSettingsPage />} />

          // Reports placeholder
          <Route path="reports/*" element={<AdminPlaceholderPage title="Reports" />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
*/

// ── 6. AdminSettingsPage URL-aware version (drop-in replacement) ──
// Replace the top of AdminSettingsPage.tsx with:
/*
export default function AdminSettingsPage() {
  const { section = 'general' } = useParams<{ section?: string }>();
  const navigate = useNavigate();
  const activeSection = section as Section;
  const setActiveSection = (s: Section) => navigate(`/settings/${s}`);

  // rest of component unchanged ...
}
*/

// ── 7. Service registrations for Program.cs ───────────────────
/*
// In BdStockOMS.API/Program.cs, add inside builder.Services block:

builder.Services.AddScoped<IAdminSettingsService, AdminSettingsService>();
builder.Services.AddScoped<IAdminFeeService, AdminFeeService>();
builder.Services.AddScoped<IAdminAuditService, AdminAuditService>();
builder.Services.AddScoped<IAdminBackupService, AdminBackupService>();
builder.Services.AddScoped<IAdminFixService, AdminFixService>();
builder.Services.AddScoped<IAdminRoleService, AdminRoleService>();
builder.Services.AddScoped<IAdminApiKeyService, AdminApiKeyService>();
builder.Services.AddScoped<IAdminAnnouncementService, AdminAnnouncementService>();
builder.Services.AddScoped<ISystemHealthService, SystemHealthService>();
*/

// ── 8. DbContext additions ─────────────────────────────────────
/*
// In BdStockOMS.API/Data/AppDbContext.cs, add:

public DbSet<AppSetting>     AppSettings     => Set<AppSetting>();
public DbSet<AuditLog>       AuditLogs       => Set<AuditLog>();
public DbSet<FeeStructure>   FeeStructures   => Set<FeeStructure>();
public DbSet<SystemRole>     SystemRoles     => Set<SystemRole>();
public DbSet<ApiKey>         ApiKeys         => Set<ApiKey>();
public DbSet<Announcement>   Announcements   => Set<Announcement>();
public DbSet<BackupHistory>  BackupHistory   => Set<BackupHistory>();
public DbSet<IpWhitelistEntry> IpWhitelist   => Set<IpWhitelistEntry>();

// AppSetting entity:
public class AppSetting
{
    [Key]
    public string Key { get; set; } = null!;
    public string Value { get; set; } = "";
    public string Category { get; set; } = "general";
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public string UpdatedBy { get; set; } = "system";
}

// AuditLog entity:
public class AuditLog
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string UserName { get; set; } = null!;
    public string Action { get; set; } = null!;
    public string Resource { get; set; } = null!;
    public string? ResourceId { get; set; }
    public string? OldValue { get; set; }
    public string? NewValue { get; set; }
    public string IpAddress { get; set; } = "";
    public string? UserAgent { get; set; }
    public string Severity { get; set; } = "info";
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}
*/
