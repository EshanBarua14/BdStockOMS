// ============================================================
// BdStockOMS — Admin Settings Service
// File: BdStockOMS.API/Services/AdminSettingsService.cs
// ============================================================
using Microsoft.EntityFrameworkCore;
using BdStockOMS.API.Data;
using BdStockOMS.API.Models.Admin;

namespace BdStockOMS.API.Services;

// ── Interfaces ────────────────────────────────────────────────
public interface IAdminSettingsService
{
    Task<GeneralSettingsDto?> GetGeneralSettingsAsync();
    Task UpdateGeneralSettingsAsync(GeneralSettingsDto dto);
    Task<MarketSettingsDto?> GetMarketSettingsAsync();
    Task UpdateMarketSettingsAsync(MarketSettingsDto dto);
    Task<TradingRulesDto?> GetTradingRulesAsync();
    Task UpdateTradingRulesAsync(TradingRulesDto dto);
    Task<NotificationSettingsDto?> GetNotificationSettingsAsync();
    Task UpdateNotificationSettingsAsync(NotificationSettingsDto dto);
    Task<bool> SendTestEmailAsync(string email);
    Task<DataRetentionDto?> GetDataRetentionAsync();
    Task UpdateDataRetentionAsync(DataRetentionDto dto);
    Task<List<IpWhitelistEntryDto>> GetIpWhitelistAsync();
    Task<dynamic> AddIpAsync(IpWhitelistEntryDto dto);
    Task RemoveIpAsync(string id);
}

public interface IAdminFeeService
{
    Task<List<FeeStructureDto>> GetAllAsync();
    Task<FeeStructureDto> CreateAsync(FeeStructureDto dto);
    Task<bool> UpdateAsync(string id, FeeStructureDto dto);
    Task<bool> DeleteAsync(string id);
}

public interface IAdminAuditService
{
    Task LogAsync(string userName, string action, string resource, string? resourceId,
        string? detail, string ipAddress, string severity = "info");
    Task<object> GetLogsAsync(int page, int pageSize, string? severity, string? userId,
        string? resource, DateTime? from, DateTime? to);
    Task<string> ExportCsvAsync(string? from, string? to);
}

public interface IAdminBackupService
{
    Task<BackupConfigDto?> GetConfigAsync();
    Task UpdateConfigAsync(BackupConfigDto dto);
    Task<List<object>> GetHistoryAsync(int limit);
    Task TriggerBackupAsync();
    Task RestoreAsync(string backupId);
}

public interface IAdminFixService
{
    Task<FIXConfigDto?> GetConfigAsync();
    Task UpdateConfigAsync(FIXConfigDto dto);
    Task<object> GetStatusAsync();
    Task ConnectAsync();
    Task DisconnectAsync();
}

public interface IAdminRoleService
{
    Task<List<object>> GetAllAsync();
    Task<dynamic> CreateAsync(RoleDto dto);
    Task<bool> UpdateAsync(string id, RoleDto dto);
    Task<bool> DeleteAsync(string id);
}

public interface IAdminApiKeyService
{
    Task<List<object>> GetAllAsync();
    Task<dynamic> CreateAsync(CreateApiKeyDto dto);
    Task<bool> RevokeAsync(string id);
}

public interface IAdminAnnouncementService
{
    Task<List<object>> GetAllAsync(bool activeOnly);
    Task<dynamic> CreateAsync(AnnouncementDto dto);
    Task<bool> UpdateAsync(string id, AnnouncementDto dto);
    Task DeleteAsync(string id);
}

public interface ISystemHealthService
{
    Task<object> GetHealthSnapshotAsync();
}

// ── AppSettings DB Entity ─────────────────────────────────────
// Add to your DbContext:
// public DbSet<AppSetting> AppSettings => Set<AppSetting>();
//
// public class AppSetting
// {
//     public string Key { get; set; } = null!;
//     public string Value { get; set; } = null!;
//     public string Category { get; set; } = "general";
//     public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
//     public string UpdatedBy { get; set; } = "system";
// }

// ── Admin Settings Service Implementation ─────────────────────
public class AdminSettingsService : IAdminSettingsService
{
    private readonly AppDbContext _db;
    private readonly IConfiguration _config;

    public AdminSettingsService(AppDbContext db, IConfiguration config)
    {
        _db = db;
        _config = config;
    }

    // Uses AppSettings key-value table for persistence
    // Falls back to appsettings.json if DB empty
    private async Task<string?> GetAsync(string key)
    {
        try
        {
            var row = await _db.AppSettings.FindAsync(key);
            return row?.Value;
        }
        catch { return null; }
    }

    private async Task SetAsync(string key, string value, string category = "general", string updatedBy = "system")
    {
        var existing = await _db.AppSettings.FindAsync(key);
        if (existing is null)
            _db.AppSettings.Add(new() { Key = key, Value = value, Category = category, UpdatedAt = DateTime.UtcNow, UpdatedBy = updatedBy });
        else
        {
            existing.Value = value;
            existing.UpdatedAt = DateTime.UtcNow;
            existing.UpdatedBy = updatedBy;
        }
        await _db.SaveChangesAsync();
    }

    public async Task<GeneralSettingsDto?> GetGeneralSettingsAsync()
    {
        // Attempt to load from DB; return sensible defaults if not found
        return new GeneralSettingsDto(
            SystemName: await GetAsync("general.systemName") ?? "BdStockOMS",
            SystemCode: await GetAsync("general.systemCode") ?? "BDSTK",
            Timezone: await GetAsync("general.timezone") ?? "Asia/Dhaka",
            Currency: await GetAsync("general.currency") ?? "BDT",
            DateFormat: await GetAsync("general.dateFormat") ?? "DD/MM/YYYY",
            Language: await GetAsync("general.language") ?? "en",
            SupportEmail: await GetAsync("general.supportEmail") ?? "support@bdstockoms.com",
            SupportPhone: await GetAsync("general.supportPhone") ?? "",
            SessionTimeoutMinutes: int.Parse(await GetAsync("general.sessionTimeoutMinutes") ?? "30"),
            MaxLoginAttempts: int.Parse(await GetAsync("general.maxLoginAttempts") ?? "5"),
            LockoutDurationMinutes: int.Parse(await GetAsync("general.lockoutDurationMinutes") ?? "15"),
            MaintenanceMode: bool.Parse(await GetAsync("general.maintenanceMode") ?? "false"),
            MaintenanceMessage: await GetAsync("general.maintenanceMessage"),
            CompanyName: await GetAsync("general.companyName") ?? "BD Stock OMS Ltd.",
            RequireEmailVerification: bool.Parse(await GetAsync("general.requireEmailVerification") ?? "true"),
            RequireTwoFactor: bool.Parse(await GetAsync("general.requireTwoFactor") ?? "false"),
            PasswordMinLength: int.Parse(await GetAsync("general.passwordMinLength") ?? "8"),
            PasswordRequireSpecial: bool.Parse(await GetAsync("general.passwordRequireSpecial") ?? "true"),
            PasswordExpiryDays: int.Parse(await GetAsync("general.passwordExpiryDays") ?? "90")
        );
    }

    public async Task UpdateGeneralSettingsAsync(GeneralSettingsDto dto)
    {
        var tasks = new[]
        {
            SetAsync("general.systemName", dto.SystemName),
            SetAsync("general.systemCode", dto.SystemCode),
            SetAsync("general.timezone", dto.Timezone),
            SetAsync("general.currency", dto.Currency),
            SetAsync("general.dateFormat", dto.DateFormat),
            SetAsync("general.language", dto.Language),
            SetAsync("general.supportEmail", dto.SupportEmail),
            SetAsync("general.supportPhone", dto.SupportPhone),
            SetAsync("general.sessionTimeoutMinutes", dto.SessionTimeoutMinutes.ToString()),
            SetAsync("general.maxLoginAttempts", dto.MaxLoginAttempts.ToString()),
            SetAsync("general.lockoutDurationMinutes", dto.LockoutDurationMinutes.ToString()),
            SetAsync("general.maintenanceMode", dto.MaintenanceMode.ToString()),
            SetAsync("general.maintenanceMessage", dto.MaintenanceMessage ?? ""),
            SetAsync("general.companyName", dto.CompanyName),
            SetAsync("general.requireEmailVerification", dto.RequireEmailVerification.ToString()),
            SetAsync("general.requireTwoFactor", dto.RequireTwoFactor.ToString()),
            SetAsync("general.passwordMinLength", dto.PasswordMinLength.ToString()),
            SetAsync("general.passwordRequireSpecial", dto.PasswordRequireSpecial.ToString()),
            SetAsync("general.passwordExpiryDays", dto.PasswordExpiryDays.ToString()),
        };
        await Task.WhenAll(tasks);
    }

    public async Task<MarketSettingsDto?> GetMarketSettingsAsync()
    {
        return new MarketSettingsDto(
            DseOpenTime: await GetAsync("market.dseOpenTime") ?? "10:00",
            DseCloseTime: await GetAsync("market.dseCloseTime") ?? "14:30",
            CseOpenTime: await GetAsync("market.cseOpenTime") ?? "10:00",
            CseCloseTime: await GetAsync("market.cseCloseTime") ?? "14:30",
            PriceTickSize: decimal.Parse(await GetAsync("market.priceTickSize") ?? "0.10"),
            LotSize: int.Parse(await GetAsync("market.lotSize") ?? "1"),
            CircuitBreakerUpPercent: decimal.Parse(await GetAsync("market.circuitBreakerUpPercent") ?? "10"),
            CircuitBreakerDownPercent: decimal.Parse(await GetAsync("market.circuitBreakerDownPercent") ?? "10"),
            AllowPreMarket: bool.Parse(await GetAsync("market.allowPreMarket") ?? "false"),
            AllowPostMarket: bool.Parse(await GetAsync("market.allowPostMarket") ?? "false"),
            SettlementDays: int.Parse(await GetAsync("market.settlementDays") ?? "2"),
            AutoMarketClose: bool.Parse(await GetAsync("market.autoMarketClose") ?? "true"),
            TradingDays: (await GetAsync("market.tradingDays") ?? "SUN,MON,TUE,WED,THU").Split(','),
            DepthLevels: int.Parse(await GetAsync("market.depthLevels") ?? "5"),
            AllowOddLot: bool.Parse(await GetAsync("market.allowOddLot") ?? "false"),
            AllowBlockTrade: bool.Parse(await GetAsync("market.allowBlockTrade") ?? "true"),
            BlockTradeMinValue: decimal.Parse(await GetAsync("market.blockTradeMinValue") ?? "5000000"),
            ReferencePrice: await GetAsync("market.referencePrice") ?? "previous_close",
            IndexRefreshIntervalMs: int.Parse(await GetAsync("market.indexRefreshIntervalMs") ?? "1000")
        );
    }

    public async Task UpdateMarketSettingsAsync(MarketSettingsDto dto)
    {
        var tasks = new[]
        {
            SetAsync("market.dseOpenTime", dto.DseOpenTime, "market"),
            SetAsync("market.dseCloseTime", dto.DseCloseTime, "market"),
            SetAsync("market.cseOpenTime", dto.CseOpenTime, "market"),
            SetAsync("market.cseCloseTime", dto.CseCloseTime, "market"),
            SetAsync("market.priceTickSize", dto.PriceTickSize.ToString(), "market"),
            SetAsync("market.lotSize", dto.LotSize.ToString(), "market"),
            SetAsync("market.circuitBreakerUpPercent", dto.CircuitBreakerUpPercent.ToString(), "market"),
            SetAsync("market.circuitBreakerDownPercent", dto.CircuitBreakerDownPercent.ToString(), "market"),
            SetAsync("market.allowPreMarket", dto.AllowPreMarket.ToString(), "market"),
            SetAsync("market.allowPostMarket", dto.AllowPostMarket.ToString(), "market"),
            SetAsync("market.settlementDays", dto.SettlementDays.ToString(), "market"),
            SetAsync("market.autoMarketClose", dto.AutoMarketClose.ToString(), "market"),
            SetAsync("market.tradingDays", string.Join(",", dto.TradingDays), "market"),
            SetAsync("market.depthLevels", dto.DepthLevels.ToString(), "market"),
            SetAsync("market.allowOddLot", dto.AllowOddLot.ToString(), "market"),
            SetAsync("market.allowBlockTrade", dto.AllowBlockTrade.ToString(), "market"),
            SetAsync("market.blockTradeMinValue", dto.BlockTradeMinValue.ToString(), "market"),
            SetAsync("market.referencePrice", dto.ReferencePrice, "market"),
            SetAsync("market.indexRefreshIntervalMs", dto.IndexRefreshIntervalMs.ToString(), "market"),
        };
        await Task.WhenAll(tasks);
    }

    public async Task<TradingRulesDto?> GetTradingRulesAsync()
    {
        return new TradingRulesDto(
            MaxOrderValue: decimal.Parse(await GetAsync("trading.maxOrderValue") ?? "10000000"),
            MaxOrderQuantity: int.Parse(await GetAsync("trading.maxOrderQuantity") ?? "100000"),
            MaxDailyTradeValue: decimal.Parse(await GetAsync("trading.maxDailyTradeValue") ?? "50000000"),
            MinOrderValue: decimal.Parse(await GetAsync("trading.minOrderValue") ?? "1000"),
            AllowShortSell: bool.Parse(await GetAsync("trading.allowShortSell") ?? "false"),
            AllowMarginTrading: bool.Parse(await GetAsync("trading.allowMarginTrading") ?? "true"),
            MarginMultiplier: decimal.Parse(await GetAsync("trading.marginMultiplier") ?? "1.5"),
            RmsCheckEnabled: bool.Parse(await GetAsync("trading.rmsCheckEnabled") ?? "true"),
            AutoSquareOff: bool.Parse(await GetAsync("trading.autoSquareOff") ?? "true"),
            AutoSquareOffTime: await GetAsync("trading.autoSquareOffTime") ?? "14:20",
            OrderExpiryDays: int.Parse(await GetAsync("trading.orderExpiryDays") ?? "30"),
            AllowAfterHoursOrder: bool.Parse(await GetAsync("trading.allowAfterHoursOrder") ?? "false"),
            PriceTolerancePercent: decimal.Parse(await GetAsync("trading.priceTolerancePercent") ?? "2"),
            DuplicateOrderWindowMs: int.Parse(await GetAsync("trading.duplicateOrderWindowMs") ?? "500"),
            MaxOpenOrders: int.Parse(await GetAsync("trading.maxOpenOrders") ?? "50"),
            MaxOrdersPerMinute: int.Parse(await GetAsync("trading.maxOrdersPerMinute") ?? "20"),
            AllowIOC: bool.Parse(await GetAsync("trading.allowIOC") ?? "true"),
            AllowGTC: bool.Parse(await GetAsync("trading.allowGTC") ?? "true"),
            AllowFOK: bool.Parse(await GetAsync("trading.allowFOK") ?? "false"),
            RequireBOForOrder: bool.Parse(await GetAsync("trading.requireBOForOrder") ?? "true"),
            RmsLimitType: await GetAsync("trading.rmsLimitType") ?? "cash",
            ExposureLimit: decimal.Parse(await GetAsync("trading.exposureLimit") ?? "2000000"),
            AllowOrderModification: bool.Parse(await GetAsync("trading.allowOrderModification") ?? "true"),
            MaxModificationsPerOrder: int.Parse(await GetAsync("trading.maxModificationsPerOrder") ?? "5")
        );
    }

    public async Task UpdateTradingRulesAsync(TradingRulesDto dto)
    {
        // Mirror same pattern — store each field
        var tasks = typeof(TradingRulesDto).GetProperties().Select(p =>
            SetAsync($"trading.{char.ToLower(p.Name[0])}{p.Name[1..]}", p.GetValue(dto)?.ToString() ?? "", "trading"));
        await Task.WhenAll(tasks);
    }

    public async Task<NotificationSettingsDto?> GetNotificationSettingsAsync()
    {
        return new NotificationSettingsDto(
            EmailEnabled: bool.Parse(await GetAsync("notif.emailEnabled") ?? "true"),
            SmtpHost: await GetAsync("notif.smtpHost") ?? "smtp.gmail.com",
            SmtpPort: int.Parse(await GetAsync("notif.smtpPort") ?? "587"),
            SmtpUser: await GetAsync("notif.smtpUser") ?? "",
            SmtpPassword: await GetAsync("notif.smtpPassword") ?? "",
            SmtpUseTls: bool.Parse(await GetAsync("notif.smtpUseTls") ?? "true"),
            SmsEnabled: bool.Parse(await GetAsync("notif.smsEnabled") ?? "false"),
            SmsGateway: await GetAsync("notif.smsGateway"),
            SmsApiKey: await GetAsync("notif.smsApiKey"),
            NotifyOnOrderFill: bool.Parse(await GetAsync("notif.notifyOnOrderFill") ?? "true"),
            NotifyOnOrderReject: bool.Parse(await GetAsync("notif.notifyOnOrderReject") ?? "true"),
            NotifyOnLogin: bool.Parse(await GetAsync("notif.notifyOnLogin") ?? "false"),
            NotifyOnLargeOrder: bool.Parse(await GetAsync("notif.notifyOnLargeOrder") ?? "true"),
            LargeOrderThreshold: decimal.Parse(await GetAsync("notif.largeOrderThreshold") ?? "1000000"),
            DailyReportEnabled: bool.Parse(await GetAsync("notif.dailyReportEnabled") ?? "true"),
            DailyReportTime: await GetAsync("notif.dailyReportTime") ?? "16:00",
            DailyReportRecipients: await GetAsync("notif.dailyReportRecipients"),
            AlertOnSystemDown: bool.Parse(await GetAsync("notif.alertOnSystemDown") ?? "true"),
            AlertOnRMSBreach: bool.Parse(await GetAsync("notif.alertOnRMSBreach") ?? "true"),
            AlertOnCircuitBreaker: bool.Parse(await GetAsync("notif.alertOnCircuitBreaker") ?? "true")
        );
    }

    public async Task UpdateNotificationSettingsAsync(NotificationSettingsDto dto)
    {
        var tasks = typeof(NotificationSettingsDto).GetProperties().Select(p =>
            SetAsync($"notif.{char.ToLower(p.Name[0])}{p.Name[1..]}", p.GetValue(dto)?.ToString() ?? "", "notifications"));
        await Task.WhenAll(tasks);
    }

    public async Task<bool> SendTestEmailAsync(string email)
    {
        // Inject IEmailService and call it
        return await Task.FromResult(true); // placeholder
    }

    public async Task<DataRetentionDto?> GetDataRetentionAsync()
    {
        return new DataRetentionDto(
            OrderHistoryDays: int.Parse(await GetAsync("retention.orderHistoryDays") ?? "365"),
            TradeHistoryDays: int.Parse(await GetAsync("retention.tradeHistoryDays") ?? "1825"),
            AuditLogDays: int.Parse(await GetAsync("retention.auditLogDays") ?? "730"),
            SignalrLogDays: int.Parse(await GetAsync("retention.signalrLogDays") ?? "7"),
            SessionLogDays: int.Parse(await GetAsync("retention.sessionLogDays") ?? "90"),
            PortfolioSnapshotDays: int.Parse(await GetAsync("retention.portfolioSnapshotDays") ?? "365"),
            AutoArchive: bool.Parse(await GetAsync("retention.autoArchive") ?? "true"),
            ArchiveToS3: bool.Parse(await GetAsync("retention.archiveToS3") ?? "false"),
            PurgeEnabled: bool.Parse(await GetAsync("retention.purgeEnabled") ?? "false")
        );
    }

    public async Task UpdateDataRetentionAsync(DataRetentionDto dto)
    {
        var tasks = typeof(DataRetentionDto).GetProperties().Select(p =>
            SetAsync($"retention.{char.ToLower(p.Name[0])}{p.Name[1..]}", p.GetValue(dto)?.ToString() ?? "", "retention"));
        await Task.WhenAll(tasks);
    }

    public Task<List<IpWhitelistEntryDto>> GetIpWhitelistAsync() =>
        Task.FromResult(new List<IpWhitelistEntryDto>());

    public Task<dynamic> AddIpAsync(IpWhitelistEntryDto dto) =>
        Task.FromResult<dynamic>(new { Id = Guid.NewGuid().ToString(), dto.Ip, dto.Label, AddedAt = DateTime.UtcNow.ToString("yyyy-MM-dd") });

    public Task RemoveIpAsync(string id) => Task.CompletedTask;
}

// ── System Health Service Implementation ──────────────────────
public class SystemHealthService : ISystemHealthService
{
    private readonly AppDbContext _db;
    private readonly IConnectionMultiplexer? _redis;

    public SystemHealthService(AppDbContext db, IConnectionMultiplexer? redis = null)
    {
        _db = db;
        _redis = redis;
    }

    public async Task<object> GetHealthSnapshotAsync()
    {
        var dbStatus = "healthy";
        try { await _db.Database.CanConnectAsync(); } catch { dbStatus = "down"; }

        var redisStatus = "healthy";
        try { if (_redis is null || !_redis.IsConnected) redisStatus = "down"; } catch { redisStatus = "down"; }

        return new
        {
            dbStatus,
            redisStatus,
            signalrStatus = "healthy",
            fixStatus = "disconnected",
            cpuUsage = GetCpuUsage(),
            memoryUsage = GetMemoryUsage(),
            diskUsage = GetDiskUsage(),
            activeConnections = Environment.ProcessorCount * 5, // approximate
            apiVersion = "1.0.0",
            buildDate = "2025-07-01",
            uptimeSeconds = (long)(DateTime.UtcNow - System.Diagnostics.Process.GetCurrentProcess().StartTime.ToUniversalTime()).TotalSeconds,
        };
    }

    private static int GetCpuUsage()
    {
        try
        {
            var proc = System.Diagnostics.Process.GetCurrentProcess();
            return (int)Math.Min(100, proc.TotalProcessorTime.TotalMilliseconds / Environment.ProcessorCount / 100);
        }
        catch { return 0; }
    }

    private static int GetMemoryUsage()
    {
        try
        {
            var proc = System.Diagnostics.Process.GetCurrentProcess();
            var totalMb = GC.GetGCMemoryInfo().TotalAvailableMemoryBytes / 1024 / 1024;
            var usedMb = proc.WorkingSet64 / 1024 / 1024;
            return (int)(totalMb > 0 ? (usedMb * 100 / totalMb) : 0);
        }
        catch { return 0; }
    }

    private static int GetDiskUsage()
    {
        try
        {
            var drive = new System.IO.DriveInfo(System.IO.Path.GetPathRoot(System.IO.Directory.GetCurrentDirectory())!);
            return (int)((drive.TotalSize - drive.AvailableFreeSpace) * 100 / drive.TotalSize);
        }
        catch { return 0; }
    }
}

// ── Audit Service Implementation ──────────────────────────────
public class AdminAuditService : IAdminAuditService
{
    private readonly AppDbContext _db;

    public AdminAuditService(AppDbContext db) { _db = db; }

    public async Task LogAsync(string userName, string action, string resource, string? resourceId,
        string? detail, string ipAddress, string severity = "info")
    {
        _db.AuditLogs.Add(new()
        {
            Id = Guid.NewGuid().ToString(),
            UserName = userName,
            Action = action,
            Resource = resource,
            ResourceId = resourceId,
            NewValue = detail,
            IpAddress = ipAddress,
            Severity = severity,
            Timestamp = DateTime.UtcNow,
        });
        await _db.SaveChangesAsync();
    }

    public async Task<object> GetLogsAsync(int page, int pageSize, string? severity, string? userId,
        string? resource, DateTime? from, DateTime? to)
    {
        var query = _db.AuditLogs.AsQueryable();
        if (!string.IsNullOrEmpty(severity)) query = query.Where(l => l.Severity == severity);
        if (!string.IsNullOrEmpty(userId)) query = query.Where(l => l.UserName == userId);
        if (!string.IsNullOrEmpty(resource)) query = query.Where(l => l.Resource == resource);
        if (from.HasValue) query = query.Where(l => l.Timestamp >= from.Value);
        if (to.HasValue) query = query.Where(l => l.Timestamp <= to.Value);

        var total = await query.CountAsync();
        var items = await query.OrderByDescending(l => l.Timestamp).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
        return new { total, items };
    }

    public async Task<string> ExportCsvAsync(string? from, string? to)
    {
        var query = _db.AuditLogs.AsQueryable();
        if (!string.IsNullOrEmpty(from) && DateTime.TryParse(from, out var f)) query = query.Where(l => l.Timestamp >= f);
        if (!string.IsNullOrEmpty(to) && DateTime.TryParse(to, out var t)) query = query.Where(l => l.Timestamp <= t);
        var logs = await query.OrderByDescending(l => l.Timestamp).Take(10000).ToListAsync();

        var sb = new System.Text.StringBuilder();
        sb.AppendLine("Timestamp,UserName,Action,Resource,ResourceId,IpAddress,Severity");
        foreach (var l in logs)
            sb.AppendLine($"{l.Timestamp:O},{l.UserName},{l.Action},{l.Resource},{l.ResourceId},{l.IpAddress},{l.Severity}");
        return sb.ToString();
    }
}
